var express = require('express')
var router = express.Router()

var bd = require('./bd')

//Alta de registros
router.get('/alta', function (req, res, next) {
  res.render('altaarticulos')
})


router.post('/alta', function (req, res, next) {
  const registro = {
    id: req.body.id,
    fecha: req.body.fecha,
    estadio: req.body.estadio,
    argentina: req.body.argentina,
    brasil: req.body.brasil,
    ganador: req.body.ganador
  }
  bd.query('insert into partidos set ?', registro, function (error, resultado) {
    if (error) {
      console.log(error)
      return
    }
  })
  res.render('mensajearticulos', { mensaje: 'La carga se efectuo correctamente' })
})


//Listado de registros
router.get('/listado', function (req, res, next) {
  bd.query('select id,fecha,estadio,argentina,brasil,ganador from partidos', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('listararticulos', { articulos: filas })
  })
})


//Consulta
router.get('/consulta', function (req, res, next) {
  res.render('consultaarticulos')
})


router.post('/consulta', function (req, res, next) {
  bd.query('select id,fecha,estadio,argentina,brasil,ganador from partidos where id=?', req.body.id, function (error, filas) {
    if (error) {
      console.log('error en la consulta')
      return
    }
    if (filas.length > 0) {
      res.render('listadoconsulta', { articulos: filas })
    } else {
      res.render('mensajearticulos', { mensaje: 'No existe el codigo de articulo ingresado' })
    }
  })
})


//Modificacion
router.get('/modificacion', function (req, res, next) {
  res.render('consultamodificacion')
})


router.post('/modificar', function (req, res, next) {
  bd.query('select id,fecha,estadio,argentina,brasil,ganador from partidos where id=?', req.body.id, function (error, filas) {
    if (error) {
      console.log('error en la consulta')
      return
    }
    if (filas.length > 0) {
      res.render('formulariomodifica', { articulos: filas })
    } else {
      res.render('mensajearticulos', { mensaje: 'No existe el codigo de articulo ingresado' })
    }
  })
})


router.post('/confirmarmodifica', function (req, res, next) {
  const registro = {
    id: req.body.id,
    fecha: req.body.fecha,
    estadio: req.body.estadio,
    argentina: req.body.argentina,
    brasil: req.body.brasil,
    ganador: req.body.ganador
  }
  bd.query('UPDATE partidos SET ? WHERE ?', [registro, { id: req.body.id }], function (error, filas) {
    if (error) {
      console.log('error en la consulta')
      console.log(error)
      return
    }
    res.render('mensajearticulos', { mensaje: 'El articulo fue modificado' })
  })
})

//Eliminar
router.get('/eliminacion', function (req, res, next) {
  res.render('consultaeliminacion')
})


router.post('/eliminar', function (req, res, next) {
  bd.query('DELETE FROM partidos WHERE id = ?', req.body.id, function (error, filas) {
    console.log(req.body)
    if (error) {
      console.log('error en la consulta')
      return
    }
  })
  res.render('mensajearticulos', { mensaje: 'El partido fue eliminado' })
})

router.get('/decada', function (req, res, next) {
  bd.query('SELECT * FROM `partidos` WHERE fecha BETWEEN 1990 AND 1999', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('decada', { articulos: filas })
  })
})

router.get('/argentina', function (req, res, next) {
  bd.query('SELECT * FROM `partidos` WHERE ganador = "Argentina"', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('argentina', { articulos: filas })
  })
})

router.get('/brasil', function (req, res, next) {
  bd.query('SELECT * FROM `partidos` WHERE ganador = "Brasil"', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('brasil', { articulos: filas })
  })
})

router.get('/golesA', function (req, res, next) {
  bd.query('SELECT SUM(argentina) as sum FROM partidos', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('golesA', { articulos: filas })
  })
})

router.get('/golesB', function (req, res, next) {
  bd.query('SELECT SUM(brasil) as suma FROM partidos', function (error, filas) {
    if (error) {
      console.log('error en el listado')
      return
    }
    res.render('golesB', { articulos: filas })
  })
})

module.exports = router